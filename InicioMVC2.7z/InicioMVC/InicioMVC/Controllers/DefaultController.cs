﻿using InicioMVC.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InicioMVC.Controllers
{
    public class DefaultController : Controller
    {
        public ActionResult Index()
        {
            List<int> lista = new List<int>()
            {
                10, 20, 30
            };
            ViewBag.Lista = lista;
            return View();
        }

        public ActionResult Pagina()
        {
            Pessoa p = new Pessoa()
            {
                Id = 8,
                Nome = "AAA"
            };

            Pessoa p2 = new Pessoa()
            {
                Id = 1233,
                Nome = "jksdhkj"
            };


            List<Pessoa> lista = new List<Pessoa>();

            return View(lista);
        }

        public ActionResult Listar()
        {
            using (SqlConnection conn = SqlConn.Abrir())
            {
                using (SqlCommand cmd = new SqlCommand(@"
                    SELECT Id, Nome, Endereco,
                    Email, Nascimento, Peso
                    FROM tbPessoa
                    ORDER BY Nome ASC
                    ", conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        List<Pessoa> lista = new List<Pessoa>();

                        while (reader.Read() == true)
                        {
                            lista.Add(new Pessoa()
                            {
                                Id = reader.GetInt32(0),
                                Nome = reader.GetString(1),
                                Endereco = reader.GetString(2),
                                Email = reader.GetString(3),
                                Nascimento = reader.GetDateTime(4),
                                Peso = reader.GetDouble(5)
                            });
                        }

                        return View(lista);
                    }
                }
            }
        }
    }
}